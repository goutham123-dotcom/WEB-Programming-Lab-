<?php
session_start();
unset($_SESSION["username"]);
include_once "session1.php";
?>